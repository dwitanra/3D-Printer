                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2806295
*MINI* All In One 3D printer test by majda107 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Are you suffering from issue and can't find any way to fix it?!
Be sure to checkout guide specified to this model, <b>guide isn't complete yet (23.8.2018) but there are some cool tweaks you should definitelly know!</b>
https://3dnation504795197.wordpress.com/guide/
Here is link for those people, who wan't to support me, it won't cost you any money, only 5 seconds of your time. So If you want to support me (without any fees), go to the guide this way! <b>Thanks <3</b>
http://zipansion.com/3C9Yh

*UPDATE 17.06.2018*
- I've added version of this test with no text to "files" section, hope this helps!

!CHECKOUT NEWEST AND MORE COMPACT AIO 3D PRINTER TEST HERE :
https://www.thingiverse.com/thing:2975429 !

After my latest design (All In One 3D printer test) got really popular, I've decided to make new, better, smaller and more detailed design.

I've literally started again from scratch, with few things in head - make it smaller, more detailed, and low on material. I think that I've done pretty good job!

!PRINT THIS WITHOUT SUPPORTS AND WITH 100% INFILL!

I hope that you'll like this design, don't forget to share your own 3D printout!

As always, feel free to tip me :-).

# Print Settings

Printer: CubePro DUO
Rafts: No
Supports: No
Resolution: 200um 
Infill: 100%

Notes: 
BE SURE TO PRINT THIS WITHOUT SUPPORTS AND WITH 100% INFILL!