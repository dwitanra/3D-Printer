                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:44579
Preassembled Secret Heart Box by emmett is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

UPDATE: I have new a much better version of this design here: http://www.thingiverse.com/thing:1221494

I really enjoyed Eric Young's design of his Secret Heart Box, but I didn't relish hunting down all the required parts to put it together. One thing I learned from designing the Blossoming Lamp is that it's entirely possible to 3D print complex, preassembled mechanisms without breaking the 45-degree rule. I took it as a challenge to show that it's possible even with something as seemingly complex as this locking heart box. See the video here: http://youtu.be/PPqLB-bv4gY  

UPDATE: By popular demand, I've modified the customizer code so you can now add words to the top of the heart. Make sure your valentine knows it's just for them.  

A big Thank You to the good people at Makerbot and the bot farm for printing 100 of these as favors for my wedding. It's good to have a friend with a factory. 

# Instructions

Just print it: no assembly or extra parts required. The key to sliding mechanisms is the tolerance between the parts. I'm using 0.4mm, which on my Replicator 1 is just right to keep the parts from totally fusing together, but gives a light friction to keep them from moving too easily. When it first comes off the print bed, usually the corners are slightly fused together. Just use a putty knife or razor blade to separate them. Start by prying the lid open (the center is a strong area for prying against). Then close it again and twist the two halves (it only goes one way, see the video or pictures). 

Don't be afraid to use force; the worst that happens is it breaks and you print a new one. I made this for the Customizer App, so you can easily tweak the tolerance if you're having trouble. 0.1mm makes a lot of difference. You can also change the overall dimensions. Just keep in mind, if you make H too small, there will be no room for the mechanism and it won't work. You may also have to change the distance between the hinges if you change the size, or they might end up outside of the heart. Check the bottom view to make sure.