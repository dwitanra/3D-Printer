                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:427789
gCreate Official Rocket Ship by gCreate is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

Update December 2017
We added a new cool textured flame and updated our thumbnail. The rocket was printed in Polyalchemy Silver Elixir PLA.

Update:
We updated the model. It is now hollow and should have no errors in Simplify3D and it has flat bridges under the curved fins for easier printing on some machines. We also removed the center booster support so you must add support below the main nozzle or the print will fail.

New video tutorial series on designing, slicing and printing the gCreate Rocket!
Part 1 & 2:
https://www.youtube.com/watch?v=Dz5APml1JqU
https://www.youtube.com/watch?v=ZIF53iyyjTU

Part 3:
https://www.youtube.com/watch?v=UsArmn30JdI


To celebrate the launch of our new site we are uploading our official rocket complete with a smoke stand. This rocket comes in 4 parts and each one slips together.  
We have printed this in various filaments including Colorfabb PLA, colorfabb bronzefill, woodfill, ABS, glow in the dark and several others. The bronzefill is by far our favorite.  
Check out our site for more free models http://www.gcreate.com  
The model was created in 3ds Max 2011 but due to the export/unit issues the model is scaled up by 2540%. You may have to scale down by .0393701 depending by your slicer software. In slic3r 1.1.6 it works fine.   

An interesting note, the smoke is actually a particle simulation in 3ds Max which i used meta particles and then heavily modified as a mesh.

New Download!
Check out the remixed spiral vase rocket here:
http://www.thingiverse.com/thing:1535483

Another New Download!
Check out the Money Bank Rocket here:
http://www.thingiverse.com/thing:1555828

# Instructions

Update:  
We recommend setting the "Solid infill threshold area" to be very small (1mm^2). This is the setting in slic3r but check your program. This will help the bottom nozzles to stop from breaking off. You can also screw them back on (which we did with the bronzefill) and then they will never come off.  
We recommend printing this with a raft depending on your print surface. The model can be tricky to print until the 3 fins finally connect to the body of the rocket. After that it prints great.  
We also recommend playing with different materials. This printed amazingly well in ColorFabb woodfill and bronzefill as well as various PLA filaments. It also prints great at half size if you want a mini rocket.  
While this print doesn't require support, the center nozzle has built in support which breaks off after the print (if you want to put it on the smoke stand).