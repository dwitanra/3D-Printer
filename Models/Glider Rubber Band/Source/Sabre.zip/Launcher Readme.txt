Plastic: ABS , PLA, Nylon, PC. 

Layers: Unspec

Fill: 35% +

Perimeters: 3

Solid Layers: 2+

Orientation: Unspec

Build Notes: Unspec

Flight Notes: Unspec



