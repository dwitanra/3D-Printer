Description: A high performance spatula ideal for throwing when you damage your carefully laid tape bed.

Plastic: ABS  

Layers: .1mm

Fill: 35-60% 

Perimeters: 4

Solid Layers: 2-3

Orientation: 
45 degrees

Build Notes: 
Allow to cool before carefully removing from build platform.  Removal with a very thin plastic spatula (print one!) is preferred. Trim if necesary prior to use.

Flight Notes: 

Launching is by hand or potato canon.

a slow writhing action or Gangham style galloping motion is reccomended when throwing to achieve the maximum entertainment for onlookers.

with practice, a nearly ballistic trajectory can be achieved.

A gradual test/adjust cycle is recommended.



