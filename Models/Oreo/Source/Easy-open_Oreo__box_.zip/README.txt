                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3598919
Easy-open Oreo "box" by jpasqua is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

I saw a print of the original "Oreo Box" at MRRF 2019 being displayed by [Chris Taylor](https://www.thingiverse.com/Nerys/), and I knew I wanted to print one. After doing so, I realized that it takes quite a few turns to screw on or off the lid. I wanted quicker access to the content so I started investigating "multi lead threads". I remodeled the filling (the white part of the cookie) with these threads and now it is just a [quarter turn](https://youtu.be/LSdHXZwYKKY) to put the lid on or take it off. In fact, if you remove the lid and then just set it down on top of the base, it will screw itself down 90% of the way just based on gravity. You can see that [here](https://youtu.be/cjs_w3cRlTQ).

For convenience I've included the "cookie" STL from the original. It is unchanged. There are also two STLs for the inner and outer parts of the filling. This is the new part. Since this is my first go at multi-lead threads, I imagine there are people out there that can improve upon my design. I've supplied the Fusion 360 file to make that easier.

# Print Settings

Printer Brand: Creality
Printer: CR10S PRO
Rafts: No
Supports: Yes
Resolution: .2mm
Infill: 15%
Filament_brand: Hatchbox
Filament_color: Black / White
Filament_material: PLA

Notes: 
I printed the "cookies" on a Prusa i3 MK3 and the filling on a Creality CR-10S Pro.

I used supports only on the cookie - not the filling.

# Post-Printing

1. Remove the supports from the 2 (identical) cookie parts.
2. Ensure that the filling parts mate together properly.
3. Glue one of the filling pieces to each of the two cookie parts. I used IPS Weld-on 16 but I'm sure there are other adhesives that would work well.