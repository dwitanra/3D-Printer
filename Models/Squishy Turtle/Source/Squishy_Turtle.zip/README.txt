                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2238443
Squishy Turtle by jakejake is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

Additional shell design stls available <a href="https://gumroad.com/l/oDuMJ">here</a>.

[![jake](https://material11.com/wp-content/uploads/2019/03/additionalShells01.jpg)](https://material11.com/shop/squishy-turtle-additional-shells/)

This 3d printed turtle uses the same flex concept from my [Mini Monster Truck](https://www.thingiverse.com/thing:1557428) to create legs that allow the toy to bounce and scurry around when tapped. The head can also retract into the shell.

Check out my process for designing this thing [here](https://material11.com/3d-printed-squishy-turtles/)

[![jake](http://www.jacobstanton.com/newsite/wp-content/uploads/2017/04/IMG_6974.jpg)](https://material11.com/3d-printed-squishy-turtles/)

The model assembles with the printed H-Clips and needs no glue. The parts print without the need for supports.

If you are interested in my design process and latest 3d printing experiments, check out my [website](www.jacobstanton.com) and my [Twitter](https://twitter.com/stantonjake89).

https://www.youtube.com/watch?v=7YMq4T2ZYYQ&feature=youtu.be

1fQi4dO1prnjXr39rZPYfA+DRmnLvrtjF/Kk7N7JbSMn75r5PkDlyWWg8HoGum7l2
YoVxy1t9e2q76JUZKMYHA====

![caution](http://i.imgur.com/PFd5Uit.png)<br>
This design will probably not work with a brim unless you spend time sanding and cleaning up the edges at the base of the print. This will stick the springs together and make the center channel for the head narrower. Using a raft might also affect this.

If you are having trouble with the head sliding, I have uploaded 3 head files with the stem portion scaled to be narrower:
Head95.stl - 95% original width
Head9.stl - 90% original width
Head85.stl - 85% original width

<img src="https://cdn.thingiverse.com/assets/98/39/9b/17/79/exploded.jpg">

[//]: # (NewProjectFeature////////////////////////////////////////////////////////////////////////////////////////)
<table>
<tr>
<td colspan="2"><a href="https://www.thingiverse.com/jakejake/designs"><img src="https://raw.githubusercontent.com/jakejake10/thingiverse-signature/master/Global/header.jpg"></a></td>
</tr>
[//]: # (SocialMedia////////////////////////////////////////////////////////////////////////////////////////)
<tr>
        <td><a href="https://www.material11.com"><img src="https://raw.githubusercontent.com/jakejake10/thingiverse-signature/master/Global/material11.jpg"></a></td>
       <td><a href="https://www.patreon.com/jakejake"><img src="https://raw.githubusercontent.com/jakejake10/thingiverse-signature/master/Global/patreon.jpg"></a></td>
    </tr>
</table>
[//]: # (///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////)