                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2779285
Dragon Egg box Chi by Lalala65765 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

[ Edit: added slimmer mid rings for easier fit ]

NEEDS A LITTLE POST PROCESSING (or remix it)

Needs a bit of cleaning with a knife after printing.

Screw the the mid ring into the top. Twist it a few times so it's not stuck (if too hard push the ring against something non-splippery like concrete and twist. This holds it strongly and evenly.

With the mid ring in place on the top, glue it to the bottom with cyanoacrylate (superglue) then BEFORE IT DRIES turn the top clockwise till the top and bottom pattern aligns. This way the patterns will match when the egg is closed.

Works when scaled too, I've been down to 40%.

I join the solid egg file in case someone wants to make a better opening / closing mechanism.



# Print Settings


Notes: 
Anything goes, just need some support at the center, I used 70 degrees angle: the shape is partly self supporting, and you don't see that area much. The mid ring can be printed at finer settings for smoother operation.