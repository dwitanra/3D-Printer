                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1731676
Pikachu by Greyes64 is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

Update 11/21/2016: I have moved the position of the tail and arranged it closer to the body so it does not have the small gap that was causing it to be very fragile. I broke many of the tails when removing the small piece of support it would generate. I hope this helps. 




Everyone's favorite little thunder mouse is back in a more dynamic pose. I created it so my daughter can have her favorite pokemon to fight against the evil powers of Team Rocket (I made her a Pumpkaboo too). She loves to carry it around and make it attack. My goal is to print it life size and have it for display.

Let me know how it prints and enjoy. 

# How I Designed This

## MeshMixer

The entire model was made on meshmixer. I took a pikachu obj. and made it solid and from there did a lot of mesh manipulation to position the body in a more natural pose. Once that was done, it was time for clean up and smoothing to make it 100% solid and print ready.