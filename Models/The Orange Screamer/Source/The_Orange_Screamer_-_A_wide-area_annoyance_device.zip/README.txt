                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:455093
The Orange Screamer - A wide-area annoyance device by AndyGadget is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

This is a pocket sized turbo whistle or siren which emits a loud and extremely annoying WHEEEEEEEEEEE when you blow into it.  I've done a full write-up on Instructables : http://www.instructables.com/id/The-Orange-Screamer/  and you can see a video of it in action here : https://vimeo.com/105474925. (The camera mic doesn't really pick up the full range and volume of it.)  
This design was inspired by Instructables user Kiteman, who published a perspex laser cut version. 

# Instructions

The rotor sits on the spindle and then the lid is glued on with cyanoacrylate adhesive.  However, you will get best performance if you slightly sand the parts in contact to get rid of any roughness left from the printing.  A drop of light oil or silicone spray in the works before gluing will help things too.  Reducing friction is the name of the game.  
   
In the ZIP file there are files for the body, rotor and lid in RSDOC format (the native Designspark format) and STL format. I've also included files in SketchUp (V8) format, a THING file for use directly on a MakerBot and a file with just one rotor blade in case anyone wants to play around with the geometry. (The SKP files are an export from Designspark and I haven't tested how well they import into SketchUp.)