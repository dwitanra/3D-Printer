                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3304456
Jewelry Box with dividers by TheGreatMrBill is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

I created 2 different removable dividers for the box that separate it into 2 or 4 sections. They are the right height to place both dividers inside at the same time when giving it as a gift. I also created a box shaped floor panel that gives enough room on the sides to wrap around Velvet (what I used) or any material and glue it to the back side. I used a thick padding on the floor panel first and then used velvet material to go over (See last pictures above). When the floor panel is done, it will fit tightly in place as you push it evenly toward the floor. I put some hot glue in the bottom before I pushed the velvet floor panel down into place. Though it was so tight that the glue probably wasn't necessary. I also created a placard for the bottom of the lid so you could put a message or someone's name on it. I used some 5 minute epoxy to glue it to the lid. Yes, you could model the name right into the lid itself, but sometimes we like to have gifts printed first and ready to go before we know who we are even giving them too. So the placard makes the gift extra special and gives you flexibility to print the box before you know who the recipient is. This box and all pieces have already been scaled to what I thought was a nice sized jewelry box but you are free to scale it how you like. Though if you go smaller, I don't know how the divider pieces will do. 
Now go make someone very happy!

Link to original creators files (Also on left side of this page) https://www.thingiverse.com/thing:2746313

# Print Settings

Printer Brand: Prusa
Printer: i3 MK3
Rafts: Doesn't Matter
Supports: No
Resolution: .20
Infill: 20 to 30 for good weight
Filament_brand: Hatchbox
Filament_color: Beige
Filament_material: Wood

Notes: 
A Brim should be used for the divider pieces as they are thin and you may need better adhesion. I printed all pieces at 210 temp and 60 bed.
The heart shaped floor piece can be used as your template to cut out velvet or material to be wrapped around it. Remember to cut the fabric about 2 inches larger than the floor piece so you have enough to wrap around. I also cut slits in the fabric that extends beyond the heart shape so you can wrap the fabric and secure with hot glue in smaller sections at a time with less wrinkles.

# Post-Printing

## Printed with Hatchbox Wood

Light sanding until satisfied with the finish. Then I used a coat of Minwax Pro 'natural chestnut' wood stain. After the first coat dried I used a second coat of 'red mahogany'. After that dried I used a rag to wipe on hand rubbed polyurethane. For the colored lid inserts I used acrylic paint and an airbrush.