                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3078915
COS -  the Container Ship by vandragon_de is licensed under the Creative Commons - Attribution - Non-Commercial - No Derivatives license.
http://creativecommons.org/licenses/by-nc-nd/3.0/

# Summary

A container or cargo ship belongs to every bath tub fleet. I once drew a small and a particularly large version. The swimming characteristics are still very good even when fully loaded. 

Have fun printing :)

Even if my boats are not benchmarks (benchy), you can use them for quality control.
<iframe width="560" height="315" src="https://www.youtube.com/embed/je_ngnnx4nU" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
<iframe width="560" height="315" src="https://www.youtube.com/embed/qQY5MCH6A0Q" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>


<h2>---Have a look at EMMA, the big sister of COS---</h2>
<a href="https://www.thingiverse.com/thing:3142367"><img src="https://cdn.thingiverse.com/renders/e9/e6/03/09/3b/233d32ad129990d4c583c6db55ea5e17_preview_featured.jpg"/></a>


<h3>See what might come next</h3>
Instagram: https://www.instagram.com/vandragon_de

<h3>Support me :)</h3>
<p>
Although it is a lot of fun to draw boats and bring them to life, it takes a lot of time to research and draw. Especially the 1:1000 scale models are very time-consuming.
So I wanted to see if there are any dear enthusiasts among you who appreciate my work and support me a little bit. 
Thank you for your help :) 
<br>
<br>
<img src="https://cdn.thingiverse.com/assets/7c/36/8a/13/f7/tipdesigner.jpg"/>
<a rel="nofollow" href="https://www.patreon.com/vandragon_de" target="_blank"><img src="https://c5.patreon.com/external/logo/become_a_patron_button.png" alt="image"></a>
</p>

# Print Settings

Printer Brand: Prusa
Printer: i3 MK2S
Rafts: No
Supports: No
Resolution: 0,2
Infill: 35% and 10%

Notes: 
The infill must be printed obliquely

<b>example</b>
<img src="https://cdn.thingiverse.com/renders/00/fb/3b/30/18/f3ccdd27d2000e3f9255a7e3e2c48800_preview_featured.jpg"/>

<img src="https://cdn.thingiverse.com/renders/25/cd/93/ca/f4/2152f79eb766c06f8e09930a32492e4a_preview_featured.jpg"/>

The lower section has 35% infill, the upper 10%. For this purpose I have extended the surface layer to 6.

Multicolour was made possible by changing the filaments. As always with my Prusa and Slic3r, an M600 command was simply inserted in the appropriate places.

Dark red leaves layer  - 0 - 9mm (Layer 0-45)

Green from  - 9-19.8mm (Layer 45-99)

White from  - 19.8mm - END (Layer 99-292)

# Videos

<iframe src="//www.youtube.com/embed/je_ngnnx4nU" frameborder="0" allowfullscreen></iframe>

<iframe src="//www.youtube.com/embed/qQY5MCH6A0Q" frameborder="0" allowfullscreen></iframe>