                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1743145
The HIVE - Modular Hex Drawers by O3D is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

#####Update 04/29/2019
Module V5 uploaded. Line issue should be resolved. Please leave comments if the issue continues.
- - -
|Like this design? Please consider helping me replace filament|
|<a href="https://www.paypal.me/O3DOfficial"><img src="https://bloximages.newyork1.vip.townnews.com/wtxl.com/content/tncms/assets/v3/editorial/a/1b/a1b62cb6-4896-11e4-ae9c-001a4bcf6878/542a975bb4d60.image.png" alt="PayPal" width ="45" height="43" title="PayPal"/></a>|
|-----|
- - -
#####More Modular Drawer Systems
- [Modular Drawers 2.0](https://www.thingiverse.com/thing:2539830) (Interlocking)
- [Modular Drawers 1.0](https://www.thingiverse.com/thing:1716141) (Stackable)
- [Modular Hex Drawers](http://www.thingiverse.com/thing:1612401) (Stackable)
- [Economical Drawers](https://www.thingiverse.com/thing:1750692) (Not modular)

#####Find me on:

|<a href="https://www.myminifactory.com/users/O3D%20Official"><img src="https://on.google.com/hub/static/images/blog/uploads/myminifactory.jpg" alt="MyMiniFactory" width ="45" height="43" title="MyMiniFactory"/></a>|
|<a href="https://www.patreon.com/O3D"><img src="http://orig06.deviantart.net/5060/f/2017/020/b/a/patreon_logo_05_1_by_darkvanessalust-daw38zq.jpg" width="45" height="45" alt="Patreon" title="Patreon" /></a>|
|<a href="https://www.paypal.me/O3DOfficial"><img src="https://bloximages.newyork1.vip.townnews.com/wtxl.com/content/tncms/assets/v3/editorial/a/1b/a1b62cb6-4896-11e4-ae9c-001a4bcf6878/542a975bb4d60.image.png" alt="PayPal" width ="45" height="43" title="PayPal"/></a>|
|<a href="https://www.shapeways.com/shops/o3d"><img src="https://static1.sw-cdn.net/files/cms/brand-resources/spark-on-blue-rgb-20141006.png" alt="Shapeways" width="45" height="45" title="Shapeways"/></a>|
|<a href="https://pinshape.com/users/238998-o3d#designs-tab-open"><img src="https://3dprint.com/wp-content/uploads/2015/03/pinshape-logo.png" alt="Pinshape" width="45" height="45" title="Pinshape" /></a>|
|<a href="https://www.vectary.com/u/dan-oconnell"><img src="http://www.neulogy.vc/files/styles/image_circle/public/logo/vectary-logo.png?itok=lNOMXXpr" alt="Vectary" width="45" height="45" title="Vectary"/></a>|
|<a href="https://cults3d.com/en/users/O3D/creations"><img src="https://d7su5vtzm9ulg.cloudfront.net/assets/logos/cults-3d-logo-3ea51ecd3f01f4c46dae4b1a2d1a4afaf3f6ef8a833414b80d73a83d12e0f1db.svg" alt="Cults" width="45" height="57" title="Cults" /></a>|
|<a href="http://twitter.com/O3D_Official"><img src="https://static.dezeen.com/uploads/2012/06/dezeen_twitter-bird.gif" alt="Twitter" width ="45" height="45" title="Twitter"/></a>|
|<a href="https://www.instagram.com/o3d_official/"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e7/Instagram_logo_2016.svg/768px-Instagram_logo_2016.svg.png" alt="Instagram" width="45" height="45" title="Instagram"/></a>|
|<a href="https://www.facebook.com/O3Dprinting/"><img src="http://techmarketingbuffalo.com/wp-content/uploads/2013/11/facebook_logo_simple-1024x1017.jpg" alt="Facebook" width="45" height="45" title="Facebook" /></a>|
|<a href="https://www.youtube.com/channel/UCaepOL3BzpV-8Z-owHYxr5A?view_as=subscriber"><img src="http://www.underconsideration.com/brandnew/archives/youtube_logo_detail.png" alt="YouTube" width="45" height="45" title="YouTube" /></a>|
|------|

# Print Settings

Printer: Maker Select V2
Rafts: Doesn't Matter
Supports: No
Resolution: 300 microns
Infill: 5%

Notes: 
Print module at 100%
Print drawer at 99%
Wall line count: 2-3