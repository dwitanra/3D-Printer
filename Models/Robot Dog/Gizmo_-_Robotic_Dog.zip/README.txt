                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:979218
Gizmo - Robotic Dog by jakejake is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

This was an old design school project of a toy for teaching children a dog's body language to reduce the risk of bite injuries. You can see the full project [here](http://www.jacobstanton.com/projects/gizmo-electronic-pet-toy/).  

I liked the design so I decided to make it 3d printable. It's arms, legs, neck and head can rotate giving it various postures. The print snaps together with no glue or fasteners.

Prints well with standard settings, except I upped the support material density to 30%. The head relies the most on support material, and it helps the part fit more cleanly.  

Refer to the "gizmo_total.stl" for the orientations I used for all of the parts.

[//]: # (NewProjectFeature////////////////////////////////////////////////////////////////////////////////////////)
<table>
<tr>
<td colspan="2"><a href="https://www.thingiverse.com/jakejake/designs"><img src="https://raw.githubusercontent.com/jakejake10/thingiverse-signature/master/Global/header.jpg"></a></td>
</tr>
[//]: # (SocialMedia////////////////////////////////////////////////////////////////////////////////////////)
<tr>
        <td><a href="https://www.material11.com"><img src="https://raw.githubusercontent.com/jakejake10/thingiverse-signature/master/Global/material11.jpg"></a></td>
       <td><a href="https://www.patreon.com/jakejake"><img src="https://raw.githubusercontent.com/jakejake10/thingiverse-signature/master/Global/patreon.jpg"></a></td>
    </tr>
</table>
[//]: # (///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////)