                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:1763518
Micro Catapult by LukeTansell is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

Inspired by a Stratasys sample print, I decided to re-draw and improve the desktop, micro catapult. It can throw a small bit of paper, chunks of raft, and pretty much anything you can fit inside. Selected ammunition can be thrown around 2 metres, plenty to hit unaware victims at another desk!

It's a Print-In-Place model, without the need for any support material. It also takes advantage of the material properties, meaning that there are no external parts or hardware, it's just the material that allows it to flex and store energy. I was pleasantly surprised to find that the ABS/PC I printed it in doesn't break or retain a memory from being fired over 100 times. 

https://youtu.be/hgZHc_a9KLI

UPDATE 7-01-2017: I've now uploaded 'Micro_Catapult_INC._TOL..stl' which is a file with looser tolerances, for anyone having trouble with the original.

# Print Settings

Printer Brand: Up!
Printer: Up Plus2
Rafts: Doesn't Matter
Supports: No
Resolution: .25
Infill: Minimum

Notes: 
Support material is not required, but a raft will improve the seating of the axles inside their housings. Printing at .25mm is recommended. It was found that a higher resolution affects the mechanics too much. If you'd like a left-handed version, you can try mirroring it in your slicer (Some may need a '-' integer, such as '-1' in order to mirror). While some people have had it work in PLA, it is not designed for PLA. It is best to print this in ABS.

Cooling while printing the neck of the shooting arm is a must, even with ABS. To give mine a better finish, i printed a small cooling tower alongside. This shouldn't be necessary if you have decent fans on your extruder. You may also want to lower the speed on the bucket.