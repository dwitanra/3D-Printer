                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2004803
Funny Toilet Sign with background by HJ3D is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

"When you gotta go, you gotta go!"

This is a remix of energywave's Humor Toilet Sign. With a background so it can be easily attached to a toilet door. The first 1.00mm can be printed in a color, then the filament color can be changed for a great looking toilet sign. Have fun!

# Print Settings

Printer Brand: Prusa
Printer: Prusa Steel
Rafts: No
Supports: No
Resolution: 0.2
Infill: 25%

Notes: 
Printed on Prusa i3 Mk2 Original. Change layer color (using Prusa Colorchange program) at the first layer above 1.00mm, so at 0.20mm layers: change color at 1.20mm. I used white PLA and black PLA. 
Seperate man/woman signs can be found in energywave's original file. 
Thanks to energywave for the original man and woman!