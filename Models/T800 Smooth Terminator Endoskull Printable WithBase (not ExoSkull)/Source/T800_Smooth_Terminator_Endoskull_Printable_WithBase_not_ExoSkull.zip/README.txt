                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:438789
T800 Smooth Terminator Endoskull Printable WithBase (not ExoSkull) by machina is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

Edit - 2017
---------------------

Please note the file slices nicely with Cura. Some of you folks have had problems in Simplify3D - please try using Cura and you should get some great results.

Thank you for all of you sharing your great prints!


Edit - Dec 2015
----------------------
Thank  you azurial for pointing out that we named it exoskull when it's an endoskull. Frankly it's almost embarrassing that we dropped the brain as such... Thank you for the nice comment as well; much appreciated.

EDIT - July 2015  
--------------------  
We also uploaded a Terminator Genisys model:  
http://www.thingiverse.com/thing:932640  



EDIT - Nov 2014  
----------------------  
It's here: the super clean, fast to print, no-supports-required T800.  
---------------------------------------------------------------------------------  
Download version 5.4.5 !  
======================  
After hours and hours and hours of clean-up and adjustment work, this is a fairly definitive T800 model that will scale well - it prints wonderfully at 50% scale, 75% scale or 100%scale.   
It will slice with Slic3r, Cura, Simply3D, KISSlicer, etc - every slicer we threw at it did a wonderful job.  
All the little overhangs are handled (such as eye sockets, cheek bones, nose, side "robot" details, actuators are beefed up, cheek actuators beefed up and adjusted for higher quality/cleaner printing.  
Print it fast, print it small, print it big, this is a great model.  
A big thanks to all who have worked on this model before it got in our hand - Geoffro, ToScH, MUCKYCHRIS all the way to Landru.  
It's amazing how many hands this model has been through to get here. Thanks to all and enjoy.  
Use version 5.4.5 !  
Original Upload  
----------------  
The T800 model is such a nice one to display on your desk, but it needed a suitable base.  
  
Thus, our Chris set on a task of making the model easier to print and give it a base suitable for such an iconic model. There were a few issues with the other model - the jaw would come off the printbed when printing in fine quality, thus there are removable supports built into the model. Secondly, there wasn't much of footprint to touch the bed for such a large model.  
It's not an inexpensive model to print, but it attracts lots of attention and it is a great conversation piece.  
All models printed on Machina Corp X20 and X24 3D Printers, with Natureworks filament from Ultimachine and ColorFabb.  
Enjoy.