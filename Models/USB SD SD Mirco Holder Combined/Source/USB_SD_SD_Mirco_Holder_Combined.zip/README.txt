                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2835728
USB SD SD Mirco Holder Combined by iomaa is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

Video: https://youtu.be/bau8SNCgk7A


# check out our binary carabiners

<p>
Check out our <a href="https://www.ebay.com/itm/Titanium-Binary-Carabiner-Safety-Cage-with-Bottle-Opener-EDC/232847177211?hash=item3636c5f5fb%3Am%3Amqhhml7CrqJVYmtZG_Dm5Ew&var=532368555047&_sacat=0&_nkw=binary+carabiner&_from=R40&rt=nc&_trksid=m570.l1313"> <strong>titanium binary key carabiners</a></strong> 
</p>


<p>
<strong>Features</strong>:
</p>
<ul>
<strong>
<li>Safety cage to keep your keys secure</li>
<li>Grade 5 Titanium body</li>
<li>Bottle opener</li>
<li>3 sizes</li>
<li>Finishes: bead blasted, stone, or polished</li>

</ul>

![Alt text](https://cdn.thingiverse.com/assets/87/bd/01/22/bf/XXX.png)

# UBS SD Micro Holder

<p>
<strong>Holder A</strong> | 11 slots | Each slot holds 1 UBS stick, or 1 SD card, or 3 (or 2) SD Micro cards | Holds a maximum 11 UBS sticks, or a bit less thick UBS sticks, or 11 SD cards, or 28 SD Micro cards, or an undefined combination of those three.
</p>

<p>
<strong>Holder B</strong> | Same as A, but with a tighter fit.
</p>

<p>
<strong>Holder C</strong> | Same as A and B, but with a tightest fit.
</p>


<p>
<strong>Mini Version</strong> | Same as above with ABC but with 7 slots.
</p>

<p>
<strong>…………………… </strong>
</p>

<p>





<p>
We printed PLA at 0.1 mm layer, 15% infill.
</p>

<p>
Supports: NONE
</p>

<p></p>






<p>Enjoy</p>



<iframe src="//www.youtube.com/embed/bau8SNCgk7A" frameborder="0" allowfullscreen></iframe>

# Our other thingiverse projects:

<p>
<strong>
<a href="https://www.thingiverse.com/thing:2676324"> bakercube</a></strong> |
<strong>
<a href="https://www.thingiverse.com/thing:2890504"> plug saver</a></strong> |
<strong>
<a href="https://www.thingiverse.com/thing:2711059"> clamps</a></strong> |
<strong>
<a href="https://www.thingiverse.com/thing:2856931"> coins</a></strong> |
<strong>
<a href="https://www.thingiverse.com/thing:2638683"> juice squeezer</a></strong> |
<strong>
<a href="https://www.thingiverse.com/iomaa/designs"> more...</a></strong>
</p>


![Alt text](https://cdn.thingiverse.com/assets/bf/2a/ad/de/46/ba22.png)