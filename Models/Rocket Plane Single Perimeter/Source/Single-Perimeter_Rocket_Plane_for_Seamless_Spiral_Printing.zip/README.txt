                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:492176
Single-Perimeter Rocket Plane for Seamless Spiral Printing by mech-G is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

Note:  If you plan to scale this up 2x or more, make sure you use RocketPlaneFor2xScaleup to avoid certain artifacts present when trying to scale the other files.

See large print of Rocket Plane shown at Midwest RepRap Festival:
https://twitter.com/FY3TV/status/711537678806872065
(click on photo, then scroll to right for second photo)

And an even bigger one:
https://hackaday.com/2017/03/28/the-midwest-reprap-festival-spectacular/#jp-carousel-250211

Remixed from Single-Perimeter Rocket.  The only difference in print settings between this and the Rocket design is that I printed this example with .4mm layer height instead of .5mm.   Don't let the gnarly-looking polygons on the rendering of the fuselage worry you too much - the final print looks way smoother than the rendering does.  Use the larger files for a smoother surface.  The photos show some prints in clear T-glase and some in silver Solutech PLA.
 "RocketPlaneSmallSmooth.stl" has fins and wings that are thicker so it can be scaled down to 50%  and still have a good perimeter.  If you want the 5.5" long version, use RocketPlaneSmooth.stl.  If you want the 2.75" long version, use RocketPlaneSmallSmooth.stl and scale it 50% in your slicer program.  
At .5mm layer height, T-Glase will look really glassy.  At .2mm layer height, it will be more translucent and satin looking.   
Update:  Added photo of the smaller plane printed in silver Solutech PLA.  
Use RocketPlaneFor2xScaleup  if you plan to scale the plane by 2x.  Tesselation is set to finest for ultra-smooth contours, but this results in a huge file.
One of the photos shows the plane scaled down to 50% mounted onto 40% scaled stand printed from ichdruck3D's stand here: http://www.thingiverse.com/thing:198954