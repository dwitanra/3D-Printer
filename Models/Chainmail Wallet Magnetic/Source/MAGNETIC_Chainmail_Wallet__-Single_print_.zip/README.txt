                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3410753
MAGNETIC Chainmail Wallet! -Single print! by Turbo_SunShine is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Please see the announcement Video where I "improve" 5 different 3D-printable designs:
https://youtu.be/en_qw3RvsaI


After having a lot of success with my Chainmail wallets, I decided to update the link design ever so slightly and make it accommodate 6x3mm magnets!

This version requires you to pause the print at the correct layer height, then glue in the magnets, and afterwards continue the print for a seamless wallet. 

I have included 2 test pieces; 
-The magnet test, is to test your printers ability to pause and resume a prints.
-The Zipper test is used to dial in the necessary amount of Horizontal expansion compensation for the best fit, I use -0.07mm on my Ender-3

If you wish to not worry about pausing and resuming a print, see the version with exposed magnets:
https://www.thingiverse.com/thing:3410758

For assembly, see the old video i made on the Chainmail wallet:
https://youtu.be/2a0T6L4gTCs

---
Update 21.02.2019
Woohoo! BOW 2/3-2/9/19! :)

---

Feel free to leave any questions or comments!

Check out my social media for sneak peaks and memes:
[YouTube](https://www.youtube.com/user/a09a21a)
[Facebook](https://www.facebook.com/SunShine13337/)
[Instagram](https://www.instagram.com/sunshine_turbo)