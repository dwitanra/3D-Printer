                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2933021
Extremely loud and compact emergency whistle by whistleblower is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Rock-Solid and lightweight emergency whistle. Two chamber design. Painful loud, louder than the v29 and twice as loud as the "wannabe 129db" whistle.

If you have stringing problems, this whistle will not work for you, because there are a lot of retractions. Check your slicer settings. Maybe lower the print speed and/or the temperature. Increasing the retraction distance could be a good idea too.

UPDATE

I've added a second version. Slightly different shape, a little bit smaller and lighter and a different lanyard hole. But same loudness.

# Print Settings

Printer: Anycubic I3 Mega
Rafts: No
Supports: No
Resolution: 0.2 mm
Infill: 20%

Notes: 
Print on its side (as it is in the stl-file) without support.