                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3531563
Cute Mini Octopus - improved models by DrLex is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is a remix of [JR_Jae's Cute Mini Octopus](https://www.thingiverse.com/thing:3495390).

The following changes have been made, some of which were suggested by [JoGoCo](https://www.thingiverse.com/JoGoCo):
* The models have been cleaned up so they are manifold, this avoids problems with certain slicers.
* The hinges have been made slightly more robust, especially the ends should be less prone to breaking.
* A variation with the mouth replaced by a nose is provided. This makes the model marginally more anatomically correct because an octopus has its mouth on its underside, not on the side. Of course octopi don't have a nose either, but at least this model can be printed without the need for any supports and has one fewer part that could break off.
* Some clean-up to make the models more efficient.
* Rotated 22.5° such that it can be easily printed bigger on rectangular print beds.

Needless to say, this contains small parts and should not be used as a toy for little children due to possible choking hazard.

# Print Settings

Printer Brand: FlashForge
Printer: Creator Pro
Rafts: No
Supports: No
Resolution: 0.15 mm
Infill: 15%
Filament_brand: 3D Eksperten
Filament_color: Silky Gold
Filament_material: PLA

Notes: 
A layer height of 0.2 mm should work well, but 0.15 gives a smoother result (expect a 4-hour print at this resolution).
If your slicer supports variable layer height, using thinner layers for the top of the head will provide an even nicer result (in the photos, the topmost layers are 0.1 mm).

If you want to print the model with the mouth, you can choose to try the one with built-in support, or let your slicing program generate support. Of course, for the ‘nose’ model, no support is required at all.

# Post-Printing

Depending on how stringy the filament is, you may need to wiggle each joint to loosen it completely. If you place the octopus on a flat surface and rotate it, it should look like the third photo if you correctly loosened the joints.